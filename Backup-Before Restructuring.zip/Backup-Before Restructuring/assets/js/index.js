require("../css/main.css");
require("../fonts/stylesheet.css");
require("../css/-Fixed-Navbar-start-with-transparency-background-BS4-.css");
require("./-Fixed-Navbar-start-with-transparency-background-BS4-.js");
require("jquery");
// import $ from "jquery";
import "bootstrap";
import * as catme from "catme";

console.log(catme());
// import * as instagramPosts from "instagram-posts";

// async () => {
// 	console.log(await instagramPosts("cats_of_instagram"));
// };

/*
    [
        {
            id: 'BRWBBbXjT40',
            username: 'cats_of_instagram',
            time: 1488904930,
            type: 'image',
            likes: 809,
            comments: 10,
            text: 'This is my post',
            media: 'https://instagram.fbma1-1.fna.fbcdn.net/t51.2885-15/s640x640/sh0.08/e35/1231231_123123_1231231.jpg',
            …
        },
        …
    ]
    */

require("../scss/custom.scss");
console.log("Hello World");
